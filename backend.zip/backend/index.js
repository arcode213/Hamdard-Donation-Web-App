const express = require('express')
const app = express()
const port=3000;
const mongoose =require('mongoose');
const jwt= require('jsonwebtoken');
const cors = require('cors');
const nodemailer= require('nodemailer');
const otpGenerator = require('otp-generator');
const Company = require('./models/Company');
const Ngo = require('./models/Ngo');
const OTP = require('./models/OTP');

app.use(express.json());
app.use(cors());

const url='';

// Database Connection
try{
    mongoose.connect(url);
    console.log("Database Connected")
}catch(error){
    return "Database Not Connected";
}

// Function to send email
const sendverifyMail= async (name,email,otp)=>{
    try{
    
        const transporter=nodemailer.createTransport({
            host : 'smtp.gmail.com',
            port : 587,
            secure : false,
            requireTLS: true,
            auth:{
                user : '2143rehman@gmail.com',
                pass : ""
            }
        });
        const mailOptions = {
            from : '2143rehman@gmail.com',
            to: email,
            subject : 'Hamdard verification OTP',
            html : '<p>Your Verification OTP Code is : </p>'+otp+""
        }
        transporter.sendMail(mailOptions, function(error,info){
            if(error){
                console.log(error);
            }else{
                console.log("Email Send");
            }
        })
    
    }catch(error){
        console.log(error);
    }
    }
    
    // Register Company
    app.post("/register/company",async(req,res) => {
        let check;
        try{
            check = await Company.findOne({email : req.body.email});
            if(check){
                if(check.verifie){
                    return res.status(400).json({success : false, errors : "Existing Company Found With Same Email Address"});
                }else{
                    const otp =  otpGenerator.generate(6, { upperCase: false, specialChars: false });
                    sendverifyMail(req.body.name,req.body.email,otp);
                    const Otp=new OTP({
                        userID: check._id,
                        userRole: check.role,
                        otp: otp,
                    })
                    await Otp.save();
                    mongoose.connection.once('open', async () => {
                        try {
                          await OTP.createIndexes();
                          console.log('TTL index created successfully.');
                        } catch (error) {
                          console.error('Error creating TTL index:', error);
                        }
                      });
                    return res.json({success : true,message: "OTP Send To Existing Email"})
                }
            }else{
                const password= jwt.sign(req.body.password,"21532153")
                const company = new Company({
                    name: req.body.name,
                    email : req.body.email,
                    password : password,
                    role : req.body.role,
                    address : req.body.address,
                    purpose : req.body.purpose,
                    verifie: false
                });    
                
                await company.save();
                const id=company.id;
                const token = jwt.sign(id,'21532153');
                const otp =  otpGenerator.generate(6, { upperCase: false, specialChars: false });
                await sendverifyMail(req.body.name,req.body.email,otp);
                res.json({success : true, message: "OTP Send To New user Email"})
            }
        }catch(err){
            res.json({message: "Error Registering Compnay"})
            return
        }
        
    })

    // Register Ngo
    app.post("/register/ngo",async(req,res) => {
        let check;
        try{
            check = await Ngo.findOne({email : req.body.email});
            if(check){
                if(check.verifie){
                    return res.status(400).json({success : false, errors : "Existing Company Found With Same Email Address"});
                }else{
                    const otp =  otpGenerator.generate(6, { upperCase: false, specialChars: false });
                    sendverifyMail(req.body.name,req.body.email,otp);
                    const Otp=new OTP({
                        userID: check._id,
                        userRole: check.role,
                        otp: otp,
                    })
                    await Otp.save();
                    mongoose.connection.once('open', async () => {
                        try {
                          await OTP.createIndexes();
                          console.log('TTL index created successfully.');
                        } catch (error) {
                          console.error('Error creating TTL index:', error);
                        }
                      });
                    return res.json({success : true, message: "OTP Send To Your Email"})
                }
            }else{
                const password= jwt.sign(req.body.password,"21532153")
                const ngo = new Ngo({
                    name: req.body.name,
                    email : req.body.email,
                    password : password,
                    role : req.body.role,
                    address : req.body.address,
                    purpose : req.body.purpose,
                    verifie: false
                });    
                
                await ngo.save();
                const id=ngo.id;
                const token = jwt.sign(id,'21532153');
                const otp =  otpGenerator.generate(6, { upperCase: false, specialChars: false });
                await sendverifyMail(req.body.name,req.body.email,otp);
                res.json({success : true,token})
            }
        }catch(err){
            res.json({message: "Something went wrong"})
            return
        }
        
    })

    app.post('/verify-otp',async(req,res)=>{
        const check=await OTP.findOne({otp: req.body.otp});
        if(check){
            const userId= check.userID;
            if(check.role==='ngo'){
                await Ngo.findOneAndUpdate({ _id: userId },{ $set: { verifie: true } });
                await OTP.deleteOne({otp : req.body.otp})
                return res.json({status: true, message: "status updated"});
            }else{
                await Company.findOneAndUpdate({ _id: userId },{ $set: { verifie: true } });
                await OTP.deleteOne({otp : req.body.otp})
                return res.json({status: true, message: "status updated"});
            }
        }else{
            res.json({status: false, message: "OTP Invalid"});
        }
    })

    //   Creating Login Endpoint for company
    app.post('/login/company', async(req,res)=>{
    try{
        let company = await Company.findOne({email : req.body.email});
    if(company){
        const decrypt= jwt.verify(company.password,"21532153");
        const passCompare = req.body.password === decrypt;
        if(passCompare){
            const data = {
                company : {
                    name: company.name,
                    id : company.id,
                    role : company.role
                }
            }
            // const token = jwt.sign(data,'21532153');
            res.json({success : true, data})
        }else {
            res.json({success : false,errors: "Password is Incorrect"})
        }
    }else{
        res.json({success : false, errors: "Wrong Email ID"});
    }}catch(error){
        res.json({message: "Login Faild Check your internet"});
    }
    })

    // Creating NGO Login Endpoint
    app.post('/login/ngo', async(req,res)=>{
        try{ let ngo = await Ngo.findOne({email : req.body.email});
        if(ngo){
            const decrypt= jwt.verify(ngo.password,"21532153");
            const passCompare = req.body.password === decrypt;
            if(passCompare){
                const data = {
                    ngo : {
                        name: ngo.name,
                        id : ngo.id,
                        role : ngo.role
                    }
                }
                // const token = jwt.sign(data,'21532153');
                res.json({success : true, data})
            }else {
                res.json({success : false,errors: "Password is Incorrect"})
            }
        }else{
            res.json({success : false, errors: "Wrong Email ID"});
        }}catch(error){
            res.json({message: "Login Faild Check your internet"})
        }
    })

// Create end point for Display All Ngos
    app.post('/ngos', async (req,res)=>{
        try{
            let ngos=await Ngo.find({verifie : true});
            res.send({success : true, ngos});
        }catch(error){
            res.json({message: "Something went wrong Data Not Found..."})
        }
    })

app.get('/', function (req, res) {
  res.send('Hello World')
})

app.listen(3000)