import React from 'react';

const LastestCause= ({}) => {
React.useEffect(() => {
// Initialize the code
return () => {}
}, [])
return (
<div className={'line-latestcause'}>
    <div className={'latest-cause'}>
        Latest Cause
    </div>
    <div className={'div-rightlatest'}>
    </div>
    <div className={'div-leftlatest'}>
    </div>
</div>
)
}
export default LastestCause