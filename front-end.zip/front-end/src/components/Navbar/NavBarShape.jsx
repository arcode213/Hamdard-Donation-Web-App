import React from 'react';
import './style.css'
const NavBarShape = ({}) => {
React.useEffect(() => {
// Initialize the code
return () => {}
}, [])
return (
<div className={'navbarrectangle'}>
</div>
);
};
export default NavBarShape