import React from 'react';
import './Style.css'
const Footer = ({}) => {
React.useEffect(() => {
// Initialize the code
return () => {}
}, [])
return (
<div className={'footer'}>
    <div className={'footerblack'}>
    </div>
    <div className={'footerdata'}>
        <div className={'footer-quick-link'}>
            <div className={'quick-link'}>
                Quick Link
            </div>
            <div className={'home'}>
                Home
            </div>
            <div className={'about-us'}>
                About us
            </div>
            <div className={'photo-gallery'}>
                Photo gallery
            </div>
            <div className={'blog-post'}>
                Blog post
            </div>
        </div>
        <div className={'footer-get-touch'}>
            <div className={'get-in-touch'}>
                Get In Touch
            </div>
            <div className={'contact-us'}>
                Contact us
            </div>
            <div className={'our-services'}>
                Our services
            </div>
        </div>
        <div className={'footer-'}>
            <div className={'near-baldia-mirpurkhas'}>
                near baldia, Mirpurkhas
            </div>
            <div className={'address'}>
                Address
            </div>
        </div>
        <div className={'footer-news'}>
            <div className={'subcrible'}>
                <div className={'group-2541'}>
                    <div className={'newsletter'}>
                        Newsletter
                    </div>
                </div>
                <div className={'group-2863'}>
                    <div className={'rectangle-2788'}>
                    </div>
                    <div className={'enter-your-email'}>
                        Enter your email
                    </div>
                    <div className={'frame-2540'}>
                        <div className={'subscribe'}>
                            Subscribe
                        </div>
                    </div>
                    <div className={'your-email-is-safe-with-us-we-dont-spam'}>
                        Your email is safe with us,we don’t spam.
                    </div>
                </div>
            </div>
            <div className={'socialmedia'}>
                <div className={'follow-me'}>
                    Follow Me
                </div>
                <svg id="1:2978/0:1319" className={'group-3251'}></svg>
            </div>
        </div>
    </div>
    <div className={'copyright-2024'}>
        Copyright 2024.
    </div>
    <div className={'line-183'}>
    </div>
    <div className={'logofooter'}>
        <div className={'hamdard'}>
            Hamdard
        </div>
        <svg id="0:1577" className={'global-charity'}></svg>
    </div>
</div>
);
};
export default Footer