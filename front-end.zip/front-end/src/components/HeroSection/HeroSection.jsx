import './Style.css'
const HeroSection = () => {
  return (
    <>
    <div className={'landingpageppics'}>
    <div className={'mainpicworlddotted'}>
    </div>
    <svg id="0:1357" className={'pictures'}>
    </svg>
</div>
<div className={'denotebutton'}>
    <div className={'buttonframe'}>
    </div>
    <div className={'donate-now'}>
        Donate Now
    </div>
</div>
<div className={'headine'}>
    <div className={'small-changes-make-a'}>
        Small changes make a
    </div>
    <div className={'big-impact'}>
        Big impact
    </div>
</div>
<div className={'line-ourproject'}>
    <div className={'our-projects'}>
        Our Projects
    </div>
    <div className={'div-rightproject'}>
    </div>
    <div className={'div-leftproject'}>
    </div>
</div>

<div className={'line-latestcause'}>
    <div className={'latest-cause'}>
        Latest Cause
    </div>
    <div className={'div-rightlatest'}>
    </div>
    <div className={'div-leftlatest'}>
    </div>
</div>

<div className='ellips-1'>

</div>
    </>
  )
}

export default HeroSection