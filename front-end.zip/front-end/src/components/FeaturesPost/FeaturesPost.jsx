import './style.css'
const FeaturesPost = () => {
  return (
    <div className={'feature-post'}>
    <div className={'welcome-to-charity'}>
        <div className={'let-us-come-together-to-make-a-difference'}>
            Let Us Come Together To Make a Difference
        </div>
        <div className={'lorem-ipsum-dolor-sit-amet-consetetur-sadipscing-elitr-sed-diam-nonumy-tempor-invidunt-ut-labore-et-dolore-magna-aliquyam-erat-sed-diam-voluptua-at-vero-eos-et-accusam-et-justo'}>
            <div><span>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam<div className="_p"></div>nonumy tempor invidunt ut labore et dolore magna aliquyam<div className="_p"></div>erat, sed diam voluptua. At vero eos et accusam et justo.</span></div>
        </div>
        <div className={'visionmission'}>
            <div className={'mission'}>
                <div className={'missionshape'}>
                </div>
                <div className={'missionheadling'}>
                    <svg id="0:1453" className={'missionlogo'}></svg>
                    <div className={'our-mission'}>
                        Our mission
                    </div>
                </div>
                <div className={'lorem-ipsum-dolor-sit-amet-consetetur-sadipscing-elitr-sed-diam'}>
                    <div><span>Lorem ipsum dolor sit amet,<div className="_p"></div>consetetur sadipscing elitr,<div className="_p"></div>sed diam</span></div>
                </div>
            </div>
            <div className={'vission'}>
                <div className={'visionshape'}>
                </div>
                <div className={'visionheadling'}>
                    <svg id="0:1460" className={'visionlogo'}></svg>
                    <div className={'our-vission'}>
                        Our vission
                    </div>
                </div>
                <div className={'lorem-ipsum-dolor-sit-amet-consetetur-sadipscing-elitr-sed-diam-1'}>
                    <div><span>Lorem ipsum dolor sit amet,<div className="_p"></div>consetetur sadipscing elitr,<div className="_p"></div>sed diam</span></div>
                </div>
            </div>
        </div>
    </div>
    <div className={'welcome-to-charity-1'}>
        Welcome to Charity
    </div>
    <div className={'feature-post-image'}>
        <div className={'charityimage'}>
            <div className={'rectangle-2870'}>
            </div>
            <img src="https://image-resource.creatie.ai/124019209528853/124019209528855/0eedc25a5fd09749a0a6638277c712a5.png" className={'rectangle-2880'} />
        </div>
    </div>
    <div className={'charity-divideline'}>
    </div>
</div>
  )
}

export default FeaturesPost