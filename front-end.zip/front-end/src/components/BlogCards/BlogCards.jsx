import React from 'react';
import './Style.css'
const BlogCard = ({}) => {
React.useEffect(() => {
// Initialize the code
return () => {}
}, [])
return (
<div className={'blog-cards'}>
    <div className={'blog-card-2'}>
        <div className={'blogframe2'}>
        </div>
        <div className={'rectangle-2889'}>
        </div>
        <div className={'button'}>
            <div className={'donate-now'}>
                Donate Now
            </div>
        </div>
        <div className={'blogcarddata2'}>
            <div className={'homeless'}>
                Homeless
            </div>
            <div className={'children-we-work-with'}>
                Children we work with
            </div>
            <div className={'lorem-ipsum-dolor-sit-amet-consete-sadipscing-elitr-sed-diam-nonumy'}>
                <div><span>Lorem ipsum dolor sit amet, consete<div className="_p"></div>sadipscing elitr, sed diam nonumy</span><span>....</span></div>
            </div>
            <div className={'group-3224'}>
                <div className={'rectangle-2895'}>
                </div>
                <div className={'rectangle-2896'}>
                </div>
                <div className={'text-85'}>
                    85%
                </div>
                <div className={'raised-8500'}>
                    Raised: $8500
                </div>
                <div className={'goal-1-0000'}>
                    Goal: $1,0000
                </div>
                <div className={'donatone'}>
                    Donatone
                </div>
            </div>
        </div>
        <svg id="0:1503" className={'pen-path'}></svg>
    </div>
    <div className={'blog-card-3'}>
        <div className={'rectangle-2888'}>
        </div>
        <div className={'rectangle-2890'}>
        </div>
        <div className={'button-1'}>
            <div className={'donate-now-1'}>
                Donate Now
            </div>
        </div>
        <div className={'blogcarddata3'}>
            <div className={'education'}>
                Education
            </div>
            <div className={'help-for-education'}>
                Help for Education
            </div>
            <div className={'lorem-ipsum-dolor-sit-amet-consete-sadipscing-elitr-sed-diam-nonumy-1'}>
                <div><span>Lorem ipsum dolor sit amet, consete<div className="_p"></div>sadipscing elitr, sed diam nonumy</span><span>....</span></div>
            </div>
            <div className={'group-3225'}>
                <div className={'rectangle-2897'}>
                </div>
                <div className={'rectangle-2898'}>
                </div>
                <div className={'text-86'}>
                    85%
                </div>
                <div className={'raised-8501'}>
                    Raised: $8500
                </div>
                <div className={'goal-1-1'}>
                    Goal: $1,0000
                </div>
                <div className={'donatone-1'}>
                    Donatone
                </div>
            </div>
        </div>
        <svg id="0:1524" className={'pen-path-1'}></svg>
    </div>
    <div className={'blog-card-4'}>
        <div className={'blogframe4'}>
        </div>
        <div className={'rectangle-2891'}>
        </div>
        <div className={'button-2'}>
            <div className={'donate-now-2'}>
                Donate Now
            </div>
        </div>
        <div className={'blogcarddata4'}>
            <div className={'food'}>
                Food
            </div>
            <div className={'help-for-food'}>
                Help for Food
            </div>
            <div className={'lorem-ipsum-dolor-sit-amet-consete-sadipscing-elitr-sed-diam-nonumy-2'}>
                <div><span>Lorem ipsum dolor sit amet, consete<div className="_p"></div>sadipscing elitr, sed diam nonumy</span><span>....</span></div>
            </div>
            <div className={'group-3226'}>
                <div className={'rectangle-2899'}>
                </div>
                <div className={'rectangle-2900'}>
                </div>
                <div className={'text-87'}>
                    85%
                </div>
                <div className={'raised-8502'}>
                    Raised: $8500
                </div>
                <div className={'goal-1-2'}>
                    Goal: $1,0000
                </div>
                <div className={'donatone-2'}>
                    Donatone
                </div>
            </div>
        </div>
        <svg id="0:1545" className={'pen-path-2'}></svg>
    </div>
    <div className={'blog-card-main'}>
        <div className={'blogframe1'}>
        </div>
        <div className={'rectangle-2887'}>
        </div>
        <div className={'button-3'}>
            <div className={'donate-now-3'}>
                Donate Now
            </div>
        </div>
        <div className={'blogcarddata1'}>
            <div className={'medical'}>
                Medical
            </div>
            <div className={'donate-for-poor-peoples-treatment-and-medicine'}>
                <div><span>Donate for poor peoples<div className="_p"></div>treatment and medicine.</span></div>
            </div>
            <div className={'lorem-ipsum-dolor-sit-amet-consete-sadipscing-elitr-sed-diam-nonumy-3'}>
                <div><span>Lorem ipsum dolor sit amet, consete<div className="_p"></div>sadipscing elitr, sed diam nonumy</span><span>....</span></div>
            </div>
            <div className={'group-3227'}>
                <div className={'rectangle-2901'}>
                </div>
                <div className={'rectangle-2902'}>
                </div>
                <div className={'text-60'}>
                    60%
                </div>
                <div className={'raised-600'}>
                    Raised: $600
                </div>
                <div className={'goal-1-000'}>
                    Goal: $1,000
                </div>
                <div className={'donatone-3'}>
                    Donatone
                </div>
            </div>
        </div>
        <svg id="0:1571" className={'pen-path-3'}></svg>
    </div>
    <div className={'find-the-popular-cause-and-donate-them'}>
        Find the popular cause and donate them
    </div>
</div>
);
};
export default BlogCard