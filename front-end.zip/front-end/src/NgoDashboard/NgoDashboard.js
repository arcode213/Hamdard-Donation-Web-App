import React from 'react'
import  NgoDrawer from '../NgoComponents/NgoDrawer'


const NgoDashboard = () => {
  return (
    <div>
      <NgoDrawer />
    </div>
  )
}

export default NgoDashboard
