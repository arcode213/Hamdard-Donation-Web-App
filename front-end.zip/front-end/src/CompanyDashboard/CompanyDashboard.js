import React from 'react'
import CompanyDrawer from '../CompanyComponents/CompanyDrawer'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
const CompanyDashboard = () => {
  return (
    <div>
      <CompanyDrawer />
    </div>

  )
}

export default CompanyDashboard